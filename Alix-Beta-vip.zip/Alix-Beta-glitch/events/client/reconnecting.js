const Discord = require("discord.js")


module.exports = bot => {
    console.log(`Reconnecting at ${Date()}.`)
}