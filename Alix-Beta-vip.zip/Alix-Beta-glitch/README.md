<img width="150" height="150" align="left" style="float: left; margin: 0 10px 0 0;" alt="Alix-Beta" src="https://is.gd/nb1fp4">  

# Alix Beta

[![Run on Repl.it](https://repl.it/badge/github/ayaan1005/Alix-Beta)](https://repl.it/github/ayaan1005/Alix-Beta)
[![](https://img.shields.io/discord/565048515357835264.svg?logo=discord&colorB=7289DA)](https://bot.alix.gq)
[![](https://top.gg/api/widget/status/693846748824862770.svg)](https://top.gg/bot/693846748824862770/vote)
[![](https://img.shields.io/badge/discord.js-v12.0.0--dev-blue.svg?logo=npm)](https://github.com/discordjs)
[![](https://img.shields.io/badge/patreon-donate-orange.svg)](https://www.patreon.com/alixbot)

> This bot is used by more than 100k+ Discord users and more than 120+ servers.

Alix Beta Is A Open Sourced Discord Bot Can Use In Many Was Like To Make Server Full Moderation Filled, And Fun. Coded With JavaScript [Discord.js](https://discord.js.org) And [Quick.db](https://quickdb.js.org/) Made By [AyaanDEV](https://github.com/Ayaan-GuitarHost/)
<br> Feel free to add a star ⭐ to the repository to promote the project!

## Bot Setup

Check Bot Config File [Here](https://github.com/ayaan1005/Alix-Beta/blob/glitch/botconfig.json)

Example BotConfig File - 
```
{
    "token": "Your Bot Token",
    "prefix": "Bot Prefix",
    "report_channelid": "Channel ID Where Bug Reports Comes",
    "support_server": "Your Bots Support Server",
    "main_ownerid": "Your Id",
    "InstaToken": "Your Insta Token Here",
    "extra_ownerid": [
      "Owner 1",
      "Owner 2"
    ]
}

```

## Upcoming Updates

### BUGS FIX
### MORE COMMAND ADD
### DASHBOARD

## Links

*   [Commands List](https://allix.glitch.me/commands)
*   [F.A.Q](https://discord.gg/qBbgnxs)
*   [Discord](https://alix.glitch.me/community)
*   [Github](https://github.com/ayaan1005/Alix-Beta)
*   [Dashboard](https://alix.glitch.me/dashboard)
*   [Embed Gen](https://alix.glitch.me/embed)

## License

Alix Beta is licensed under the GPL 3.0 license. See the file `LICENSE` for more information. If you plan to use any part of this source code in your own bot, I would be grateful if you would include some form of credit somewhere.

## Security

For secutiry purposes check `SECURITY.md`

## Top.GG 

Vote Alix And Have 24h Free Credit Of Premium Usage `SOON!`<br><br>
<a href="https://top.gg/bot/693846748824862770" >
  <img src="https://top.gg/api/widget/693846748824862770.svg" alt="Alix" />
</a>
